<?php
/**
 * Plugin Name: IAMLL706 App Associations
 * Description: Serves Apple's AASA JSON and Android's Digital Asset Links JSON.
 * Version: 1.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Jason Cox
 */

if (!defined('ABSPATH')) {
	exit;
}

const IAMLL706_ASSOC_QUERY_VAR = 'iamll706_assoc';
const IAMLL706_AASA_ROUTE_REGEX = '^\.well-known/apple-app-site-association$';
const IAMLL706_ANDROID_ROUTE_REGEX = '^\.well-known/assetlinks\.json$';

function iamll706_assoc_add_rewrite_rules() {
	add_rewrite_rule(IAMLL706_AASA_ROUTE_REGEX, 'index.php?' . IAMLL706_ASSOC_QUERY_VAR . '=ios', 'top');
	add_rewrite_rule(IAMLL706_ANDROID_ROUTE_REGEX, 'index.php?' . IAMLL706_ASSOC_QUERY_VAR . '=android', 'top');
}

function iamll706_assoc_add_query_var($vars) {
	$vars[] = IAMLL706_ASSOC_QUERY_VAR;
	return $vars;
}

function iamll706_assoc_disable_canonical_redirect($redirect_url) {
	if (get_query_var(IAMLL706_ASSOC_QUERY_VAR)) {
		return false;
	}
	return $redirect_url;
}

function iamll706_assoc_serve_json() {
	$type = get_query_var(IAMLL706_ASSOC_QUERY_VAR);
	if (!$type) {
		return;
	}

	$payload = [];

	if ($type === 'ios') {
		$payload = [
			'webcredentials' => [
				'apps' => ['8VLBYL3SV8.org.iamll706.AskBruno'],
			],
            'applinks' => [
                'apps' => [],
                'details' => [
                    [
                        'appID' => '8VLBYL3SV8.org.iamll706.AskBruno',
                        'paths' => ['*']
                    ]
                ]
            ]
		];
	} elseif ($type === 'android') {
		$payload = [
			[
				'relation' => [
                    'delegate_permission/common.handle_all_urls', 
                    'delegate_permission/common.get_login_creds'
                ],
				'target' => [
					'namespace' => 'android_app',
					'package_name' => 'org.iamll706.askbruno',
					'sha256_cert_fingerprints' => [
						'B6:A4:ED:6D:CA:94:C4:A3:F3:9E:8B:65:00:46:E1:84:97:BD:DF:79:05:13:46:8A:C3:05:A1:74:52:ED:76:C5',
						'A9:DD:6C:C5:CA:0F:1F:55:14:B1:27:8B:42:93:EB:4E:38:C7:41:D5:DE:7E:1C:14:AF:24:F4:0B:5D:0E:D1:8E'
					]
				]
			]
		];
	} else {
		return;
	}

	status_header(200);
	header('Content-Type: application/json; charset=utf-8');
	header('Cache-Control: public, max-age=3600');
	echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
	exit;
}

function iamll706_assoc_activate() {
	iamll706_assoc_add_rewrite_rules();
	flush_rewrite_rules();
}

function iamll706_assoc_deactivate() {
	flush_rewrite_rules();
}

add_action('init', 'iamll706_assoc_add_rewrite_rules');
add_filter('query_vars', 'iamll706_assoc_add_query_var');
add_filter('redirect_canonical', 'iamll706_assoc_disable_canonical_redirect');
add_action('template_redirect', 'iamll706_assoc_serve_json', 0);

register_activation_hook(__FILE__, 'iamll706_assoc_activate');
register_deactivation_hook(__FILE__, 'iamll706_assoc_deactivate');
